# projectoR
A Shiny app for using and learning ggplot2 in R for data visualization

<a href="https://zenodo.org/doi/10.5281/zenodo.10780807"><img src="https://zenodo.org/badge/767324753.svg" alt="DOI"></a>

