library(shiny)
library(ggplot2)
library(shinyWidgets)
library(plotly)

example_data <- read.csv("default_data.csv") # Update the path to your qog.csv file





ui <- fluidPage(
  tags$head(
    tags$style(
      HTML("
        .custom-title h1 {
          color: #333;
          font-size: 35px;
          font-weight: bold;
          text-align: center;
          margin-bottom: 10px;
        }
        .code-word {
          font-family: 'Courier New', Courier, monospace;
          color: #000000; /* Custom color for code word */
          font-size: inherit; /* Inherit font size from parent */
        }
        .subtitle1 {
          font-size: 14px;
          margin-top: 20px;
          text-align: center;
          color: #777;
          font-style: italic;
        }
        .subtitle2 {
          font-size: 12px;
          margin-top: 20px;
          text-align: center;
          color: #777;
          font-style: italic;
        }
      ")
    )
  ),
  titlePanel(
    div(
      class = "custom-title",
      h1("Experimenting with",span(class = "code-word", "ggplot()")),
      div(
        class = "subtitle1",
        "Made by ",
        a(href = "https://11annah.github.io", "Hannah Schulz-Kümpel"),
        " for the course ",
        a(href = "https://11annah-s-teachings.github.io", "''Multivariate Verfahren''"),
        " in the summer semester 2024 at LMU Munich"
      ),
      div(
        class = "subtitle2",
        "Based on William Christiansen, Ph.D.'s ",
        a(href = "https://github.com/wtchristiansen/projectoR", "projectoR"),
        " - ",
        a(href = "https://sites.google.com/vt.edu/williamchristiansen/", "Visit His Website")
      )
    )
  )
,
  sidebarLayout(
    sidebarPanel(
      fileInput("file1", "Choose CSV File", accept = ".csv"),
      actionButton("loadExample", "Load Example Dataset"),
      actionButton("generatePlot", "Generate Plot"),
      downloadButton("downloadPlot", "Download Plot"),
      tags$hr(),
      tabsetPanel(
      tabPanel("Playground",
               tabsetPanel(
        tabPanel("Choosing Vars",
      uiOutput("xVarUI"),
      uiOutput("yVarUI"),
      checkboxInput("transformX", "Transform X Variable", value = FALSE),
      checkboxInput("transformY", "Transform Y Variable", value = FALSE),
      selectInput("transformXType", "X Transformation Type", choices = c("as.factor", "as.numeric"), selected = "as.factor"),
      selectInput("transformYType", "Y Transformation Type", choices = c("as.factor", "as.numeric"), selected = "as.factor")),
      tabPanel("Plot and Axis types",
               selectInput("geom", "Geometry",
                           choices = c("Point" = "geom_point", "Line" = "geom_line", "Bar" = "geom_bar", "Boxplot" = "geom_boxplot")),
               numericInput("xMin", "X-axis Min", value = NA),
               numericInput("xMax", "X-axis Max", value = NA),
               numericInput("yMin", "Y-axis Min", value = NA),
               numericInput("yMax", "Y-axis Max", value = NA),
               checkboxInput("discreteX", "Discrete X-axis", value = FALSE),
               checkboxInput("discreteY", "Discrete Y-axis", value = FALSE),
               )
      )),
      tabPanel("Making it pretty",
      colorPickr("color", "Color", preview = TRUE),
      pickerInput("fill", "Fill Color", choices = c("Blue", "Red", "Green", "Yellow"), options = list(`style` = "btn-inverse"), multiple = FALSE),
      selectInput("theme", "Theme",
                  choices = c("Default" = "theme_gray", "Minimal" = "theme_minimal", "Classic" = "theme_classic", "Light" = "theme_light", "Dark" = "theme_dark")),
      sliderInput("pointSize", "Point Size", min = 1, max = 5, value = 2),
      checkboxInput("fitLine", "Fit Line (LM)", value = FALSE),
      textInput("xTitle", "X-axis Title"),
      textInput("yTitle", "Y-axis Title"),
      textInput("graphTitle", "Graph Title"),
      textInput("graphCaption", "Graph Caption"))
      ),
      tags$hr(),
      tags$a(href = "https://william-christiansen.shinyapps.io/data_distillery/", target = "_blank", class = "btn btn-default", "Dirty data?")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel("Plot", plotOutput("plot")),
        tabPanel("Interactive version", plotlyOutput("plot_interactive")),
        tabPanel("Do It yourself",
                 textAreaInput("dataprep", "Here, you can pre-process your data", value = ""),
                 actionButton("runButton", "Run Code"),
                 verbatimTextOutput("codeoutput"),
                 textAreaInput("customField1", "Write your own from scratch (or via p+); the data is named df", value = ""),
                 actionButton("applyCustom1", "Plot it!"),
                 plotOutput("DIYplot")),
        tabPanel("Cheat Sheet", tags$iframe(style = "height:600px; width:100%", src = "data-visualization.pdf"))
      )
    )
  )
)

server <- function(input, output, session) {
  data <- reactiveVal(NULL)
  customSyntax <- reactiveVal(NULL)
  
  observeEvent(input$file1, {
    df <- read.csv(input$file1$datapath)
    data(df)
  })
  
  
  observeEvent(input$loadExample, {
    data(example_data)
    updateSelectInput(session, "xVar", choices = names(example_data))
    updateSelectInput(session, "yVar", choices = names(example_data))
  })
  
  output$xVarUI <- renderUI({
    req(data())
    selectInput("xVar", "X Variable", choices = names(data()))
  })
  
  output$yVarUI <- renderUI({
    req(data())
    selectInput("yVar", "Y Variable", choices = names(data()))
  })
  
  observeEvent(input$applyCustom1, {
    if (!is.null(input$customField1) && input$customField1 != "") {
      customSyntax(input$customField1)
    } else {
      customSyntax(NULL)
    }
  })
  
  output$plot <- renderPlot({
    req(input$generatePlot, data())
    df <- data()
    
    # Optionally transform variables
    if(input$transformX) {
      df[[input$xVar]] <- match.fun(input$transformXType)(df[[input$xVar]])
    }
    if(input$transformY) {
      df[[input$yVar]] <- match.fun(input$transformYType)(df[[input$yVar]])
    }
    
    # Use aes() for mapping
    p <- ggplot(df, aes(x = !!sym(input$xVar), y = !!sym(input$yVar))) +
      get(input$geom)(colour = input$color, size = input$pointSize, fill = input$fill) +
      labs(title = input$graphTitle, x = input$xTitle, y = input$yTitle, caption = input$graphCaption) +
      {switch(input$theme,
              "theme_gray" = theme_gray(),
              "theme_minimal" = theme_minimal(),
              "theme_classic" = theme_classic(),
              "theme_light" = theme_light(),
              "theme_dark" = theme_dark(),
              "theme_bw" = theme_bw())}
    
    # Adjust scales
    if(!is.na(input$xMin) && !is.na(input$xMax)) {
      p <- p + scale_x_continuous(limits = c(input$xMin, input$xMax))
    }
    if(!is.na(input$yMin) && !is.na(input$yMax)) {
      p <- p + scale_y_continuous(limits = c(input$yMin, input$yMax))
    }
    
    # Add confidence interval if selected and fit line
    if(input$fitLine) {
      p <- p + stat_smooth(method="lm", se=FALSE)
    }
    print(p)
  })
  
  output$plot_interactive <- renderPlotly({
    req(input$generatePlot, data())
    df <- data()
    
    # Optionally transform variables
    if(input$transformX) {
      df[[input$xVar]] <- match.fun(input$transformXType)(df[[input$xVar]])
    }
    if(input$transformY) {
      df[[input$yVar]] <- match.fun(input$transformYType)(df[[input$yVar]])
    }
    
    # Use aes() for mapping
    p <- ggplot(df, aes(x = !!sym(input$xVar), y = !!sym(input$yVar))) +
      get(input$geom)(colour = input$color, size = input$pointSize, fill = input$fill) +
      labs(title = input$graphTitle, x = input$xTitle, y = input$yTitle, caption = input$graphCaption) +
      {switch(input$theme,
              "theme_gray" = theme_gray(),
              "theme_minimal" = theme_minimal(),
              "theme_classic" = theme_classic(),
              "theme_light" = theme_light(),
              "theme_dark" = theme_dark())}
    
    # Adjust scales
    if(!is.na(input$xMin) && !is.na(input$xMax)) {
      p <- p + scale_x_continuous(limits = c(input$xMin, input$xMax))
    }
    if(!is.na(input$yMin) && !is.na(input$yMax)) {
      p <- p + scale_y_continuous(limits = c(input$yMin, input$yMax))
    }
    
    # Add confidence interval if selected and fit line
    if(input$fitLine) {
      p <- p + stat_smooth(method="lm", se=FALSE)
    }
    print(p)
  })
  
  observeEvent(input$runButton, {
    code <- input$codeInput
    outputText <- tryCatch(
      eval(parse(text = code), envir = .GlobalEnv),
      error = function(e) { as.character(e) }
    )
    output$codeoutput <- renderPrint({
      if (is.error(outputText)) {
        paste("Error:", outputText)
      } else {
        outputText
      }
    })
  })
  
  observeEvent(input$applyCustom1, {
  output$DIYplot <- renderPlot({
    req(input$generatePlot, data())
    df <- data()
    
    # Optionally transform variables
    if(input$transformX) {
      df[[input$xVar]] <- match.fun(input$transformXType)(df[[input$xVar]])
    }
    if(input$transformY) {
      df[[input$yVar]] <- match.fun(input$transformYType)(df[[input$yVar]])
    }
    
    # Use aes() for mapping
    p <- ggplot(df, aes(x = !!sym(input$xVar), y = !!sym(input$yVar))) +
      get(input$geom)(colour = input$color, size = input$pointSize, fill = input$fill) +
      labs(title = input$graphTitle, x = input$xTitle, y = input$yTitle, caption = input$graphCaption) +
      {switch(input$theme,
              "theme_gray" = theme_gray(),
              "theme_minimal" = theme_minimal(),
              "theme_classic" = theme_classic(),
              "theme_light" = theme_light(),
              "theme_dark" = theme_dark(),
              "theme_bw" = theme_bw())}
    
    # Adjust scales
    if(!is.na(input$xMin) && !is.na(input$xMax)) {
      p <- p + scale_x_continuous(limits = c(input$xMin, input$xMax))
    }
    if(!is.na(input$yMin) && !is.na(input$yMax)) {
      p <- p + scale_y_continuous(limits = c(input$yMin, input$yMax))
    }
    
    if(input$fitLine) {
      p <- p + stat_smooth(method="lm", se=FALSE)
    }
    if(!is.null(customSyntax())){
      plot <- eval(parse(text= input$customField1))
      print(plot)
    }else{
      blank <- ggplot()+theme_minimal()
      print(blank)
    }
  })
  
  })
  
  
  output$downloadPlot <- downloadHandler(
    filename = function() {
      paste("plot-", Sys.Date(), ".png", sep="")
    },
    content = function(file) {
      # Use the plot object directly
      ggsave(file, device = "png", width = 10, height = 8)
    }
  )
}

shinyApp(ui, server)
